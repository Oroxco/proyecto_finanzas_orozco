import{a,b}from"./chunk-EQJFF4HI.js";import"./chunk-USOVSZMV.js";import"./chunk-4LKUOUX5.js";b();export{a as mdTransitionAnimation};
